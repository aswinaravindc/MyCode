var cards = ['1','1','2','2','3','3','4','4','5','5','6','6','7','7','8','8','9','9','10','10','11','11','12','12','13','13','14','14','15','15','16','16','17','17','18','18','19','19','20','20','21','21'];
var cardsEasy = cards.slice(0,8);
var cardsMedium = cards.slice(0,20);
var cardsHard = cards.slice(0,30);
var cardsExtraHard = cards.slice(0,42);
var flippedCards = [];
var flippedCardsVal = 0;
var flippedcardsTot = 0;
var whichCardSet = [];
var matrix = [];
var processed = 0;
var score = 0;

$(document).ready(function(){
	$("#restartBtn").hide();
	$("#winner").hide();
	//Initial game load after capturing the difficulty level
	$("input[name=diffLevel]").change(function(){
		$("#winner").hide();
		var whichLevel = this.value;
		$("#gameBoardWhich").removeClass();
		score = 0;
		if(whichLevel == "easy"){
			$("#gameBoardWhich").addClass("gameBoardEasy");
			matrix = [['0','1','2','3'],['4','5','6','7']];
			createBoard(cardsEasy);
			whichCardSet = cardsEasy;
			$("#score").html("Score: 0/4");
		}
		else if(whichLevel == "medium"){
			$("#gameBoardWhich").addClass("gameBoardMedium");
			matrix = [['0','1','2','3','4'],['5','6','7','8','9'],['10','11','12','13','14'],['15','16','17','18','19']];
			createBoard(cardsMedium);
			whichCardSet = cardsMedium;
			$("#score").html("Score: 0/10");
		}
		else if(whichLevel == "hard"){
			$("#gameBoardWhich").addClass("gameBoardHard");
			matrix = [['0','1','2','3','4','5'],['6','7','8','9','10','11'],['12','13','14','15','16','17'],['18','19','20','21','22','23'],['24','25','26','27','28','29']];
			createBoard(cardsHard);
			whichCardSet = cardsHard;
			$("#score").html("Score: 0/15");
		}
		else if(whichLevel == "extraHard"){
			$("#gameBoardWhich").addClass("gameBoardExtraHard");
			matrix = [['0','1','2','3','4','5','6'],['7','8','9','10','11','12','13'],['14','15','16','17','18','19','20'],['21','22','23','24','25','26','27'],['28','29','30','31','32','33','34'],['35','36','37','38','39','40','41']];
			createBoard(cardsExtraHard);
			whichCardSet = cardsExtraHard;
			$("#score").html("Score: 0/21");
		}
		if($("input[name=diffLevel]").is(':checked')){ 
			$("#restartBtn").show();
		}
	});	
});

//Function to calculate the score
function calculateScore(){
	score += 1;
	if(whichCardSet == cardsEasy)
		$("#score").html("Score: "+ score + "/4");
	else if(whichCardSet == cardsMedium)
		$("#score").html("Score: "+ score + "/10");
	else if(whichCardSet == cardsHard)
		$("#score").html("Score: "+ score + "/15");
	else if(whichCardSet == cardsExtraHard)
		$("#score").html("Score: "+ score + "/21");
}

//Function to flip the card
function flipCard(card,i){
	if($(card).html() == '' && processed == 0){
		processed = 1;
		$(card).addClass('flipCard');
		setTimeout(function(){
			$(card).css('background', 'none');
		}, 600);
		setTimeout(function(){
			$(card).removeClass('flipCard');
			$(card).html(cards[i]);
		}, 800);
		
		if(flippedCards.length == 0){
			flippedCards.push(card);
			flippedCardsVal = cards[i];
			processed = 0;
		}
		else if(flippedCards.length == 1){
			if(flippedCardsVal == cards[i]){
				flippedCards = [];
				flippedCardsVal = 0;
				flippedcardsTot += 2;
				calculateScore();
				if(flippedcardsTot == whichCardSet.length){
					flippedcardsTot = 0;
					setTimeout(function(){
						$("#winner").show();
					}, 1500);
				}
				processed = 0;
			}
			else{
				setTimeout(function(){
					$(card).css('background', 'url(img/card.png) no-repeat');
					$(card).html("");
					$(flippedCards[0]).css('background', 'url(img/card.png) no-repeat');
					$(flippedCards[0]).html("");
					flippedCards = [];
					flippedCardsVal = 0;
					processed = 0;
				}, 1200);
			}	
		}
	}
}

//Function to create the game board
function createBoard(whichCardSet){
	$("#winner").hide();
	score = 0;
	if(whichCardSet == cardsEasy)
		$("#score").html("Score: 0/4");
	else if(whichCardSet == cardsMedium)
		$("#score").html("Score: 0/10");
	else if(whichCardSet == cardsHard)
		$("#score").html("Score: 0/15");
	else if(whichCardSet == cardsExtraHard)
		$("#score").html("Score: 0/21");
	var board="";
	flippedCards = [];
	flippedCardsVal = 0;
	flippedcardsTot = 0;
	for(var i=0; i<whichCardSet.length; i++){
		board += "<div id=\"card" + i +"\" onclick=\"flipCard(this," + i + ")\"></div>";
	}
	$("#gameBoardWhich").html(board);
	
	var j = 0; 
	var k = 0;
	var top = 0; 
	var left = 0; 
	var delay = 0;
	
	var bottom = matrix.length; 
	var right = matrix[0].length;
	
	
	while (top < bottom && left < right) {
		for (j = left; j < right; j++){
			k = matrix[top][j];
			$("#card"+k).delay(delay).animate({
				opacity:1
			},1000);
			delay += 500;
		}
		top++;
		
		for (j = top; j < bottom; j++) {
			k = matrix[j][right - 1];
			$("#card"+k).delay(delay).animate({
				opacity:1
			},1000);
			delay += 500;
		}
		right--;

		if (top < bottom) {
			for (j = right - 1; j >= left; j--) {
				k = matrix[bottom - 1][j];
				$("#card"+k).delay(delay).animate({
					opacity:1
				},1000);
				delay += 500;
			}
			bottom--;
		}

		if (left < right) {
			for (j = bottom - 1; j >= top; j--) {
				k = matrix[j][left];
				$("#card"+k).delay(delay).animate({
					opacity:1
				},1000);
				delay += 500;
			}
			left++;
		}
	}
}



